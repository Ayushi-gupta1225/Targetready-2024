
rootProject.name = "kotlin-test-demo"

